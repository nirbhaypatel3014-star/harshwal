const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
app.use(express.json());

const db = new sqlite3.Database(__dirname + '/../db/loans.db');

// Simple fake auth — token never expires, and there's no check that it's
// actually valid beyond "is it present". Intentional for Part C.
app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'admin123') {
    return res.json({ token: 'fake-static-token-123' });
  }
  res.status(401).json({ error: 'invalid credentials' });
});

app.get('/loans', (req, res) => {
  db.all('SELECT * FROM loans', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// BUG (Part A, easy-medium): no validation on amount — accepts negative or zero.
app.post('/loans', (req, res) => {
  const { customer_id, amount } = req.body;
  db.run(
    'INSERT INTO loans (customer_id, amount, status) VALUES (?, ?, ?)',
    [customer_id, amount, 'pending'],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, customer_id, amount, status: 'pending' });
    }
  );
});

// BUG (Part A, medium): disbursing the same loan twice creates two transactions —
// no idempotency check on loan status before disbursing again.
app.post('/loans/:id/disburse', (req, res) => {
  const loanId = req.params.id;
  db.get('SELECT * FROM loans WHERE id = ?', [loanId], (err, loan) => {
    if (err || !loan) return res.status(404).json({ error: 'loan not found' });
    db.run(
      'INSERT INTO transactions (loan_id, amount, type) VALUES (?, ?, ?)',
      [loanId, loan.amount, 'disbursement'],
      function (err2) {
        if (err2) return res.status(500).json({ error: err2.message });
        db.run('UPDATE loans SET status = ? WHERE id = ?', ['disbursed', loanId]);
        res.json({ message: 'disbursed', loan_id: loanId, transaction_id: this.lastID });
      }
    );
  });
});

// BUG (Part B, the SQL discriminator): this "balance" endpoint sums transactions
// but has a subtly wrong WHERE clause — it filters by type = 'disbursement' only,
// silently ignoring 'repayment' transactions, so any customer who has made a
// repayment will show an inflated outstanding balance. Candidate should catch this
// via direct SQL querying of the DB, not just via the API.
app.get('/customers/:id/balance', (req, res) => {
  const customerId = req.params.id;
  const sql = `
    SELECT SUM(t.amount) as outstanding
    FROM transactions t
    JOIN loans l ON l.id = t.loan_id
    WHERE l.customer_id = ? AND t.type = 'disbursement'
  `;
  db.get(sql, [customerId], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ customer_id: customerId, outstanding: row.outstanding || 0 });
  });
});

// Admin endpoint — only checks a token is present, not that it's the right one
// in any meaningful way, and there's no expiry. Part C.
app.get('/admin/loans', (req, res) => {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'missing token' });
  db.all('SELECT * FROM loans', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

const PORT = 4000;
app.listen(PORT, () => console.log(`Loan Tracker API running on port ${PORT}`));
