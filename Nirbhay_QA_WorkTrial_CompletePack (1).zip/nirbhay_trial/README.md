# Harshwal Consulting — QA Work Trial

Welcome. This exercise mirrors real QA work on a small financial application —
close to the loan-workflow domain you've worked in before. No coding/automation
scripting is required; this is a manual + SQL + API testing exercise.

**Tools & AI policy:** Documentation and your own notes are fine. Please don't use
AI tools (ChatGPT, Claude, etc.) to generate your test cases or bug reports — we
want to see your own testing instincts, and we'll ask you to walk through your
reasoning on a follow-up call.

**Submission:** Reply to this email with your deliverables (test plan, bug
reports, SQL queries + answers, Postman collection export) within 48 hours.

---

## What's provided

A small "Loan Tracker" API (`app/server.js`) backed by a SQLite database
(`db/loans.db`) with 3 customers, 3 loans, and a handful of transactions already
seeded.

**To run it:**
```
cd app
npm install
npm start
```
The API will be running at `http://localhost:4000`.

**Endpoints:**
- `POST /auth/login` — body: `{"username": "admin", "password": "admin123"}`
- `GET /loans`
- `POST /loans` — body: `{"customer_id": 1, "amount": 50000}`
- `POST /loans/:id/disburse`
- `GET /customers/:id/balance`
- `GET /admin/loans` — requires an `Authorization` header (any value currently works — is that a problem?)

You can inspect the database directly with any SQLite client (DB Browser for
SQLite, or the `sqlite3` command-line tool) — `db/loans.db`.

---

## Part A — Manual Testing & Bug Reports (Medium)

Test the API's core loan lifecycle: creating a loan, disbursing it, and checking
a customer's balance. Using Postman (or curl, your choice):

1. Write at least 10 test cases covering functional, boundary, and negative
   scenarios for `POST /loans` and `POST /loans/:id/disburse`.
2. Execute them and find at least 2 real bugs. For each, write a proper bug
   report: title, steps to reproduce, expected vs actual, severity.
3. One hint: try creating a loan with a negative or zero amount. Another hint:
   try disbursing the same loan twice in a row and see what happens to the
   balance afterward.

## Part B — SQL / Backend Validation (Hard — this is the part we weight most)

Customer 1 (Ramesh Kumar, loan id 1) has made both a disbursement and a
repayment. Query the database directly and answer:

1. What does `GET /customers/1/balance` report as his outstanding balance?
2. Using SQL directly against `loans.db`, calculate what his outstanding balance
   *should actually be*, accounting for all his transactions (disbursements and
   repayments).
3. Do the two numbers match? If not, write the SQL query you used to find the
   discrepancy, and explain in plain language what's wrong with the API's
   balance calculation — not just "it's wrong," but the actual mechanism.

## Part C — API/Auth Testing (Medium)

1. Test `GET /admin/loans` with no `Authorization` header, then with a clearly
   fake token (e.g., `Authorization: Bearer literally-anything`). What happens?
   Is this a real security problem, and if so, how would you describe its
   severity in a bug report?
2. Export a Postman collection covering the endpoints you tested, with at least
   basic assertions (status code checks) on each request, and include it in
   your submission.

## Part D — Short write-up (10 minutes)

In a few sentences: if this were a real production loan system processing
thousands of transactions daily, what's the one test or monitoring check you'd
push hardest to have in place, based on the bugs you found today?

---

## What To Submit — Checklist

Reply to the original email within **48 hours** with:

- [ ] Your test cases for Part A (at least 10) — you can use the
      `Submission_Template.docx` file included in this pack, or your own format
- [ ] At least 2 bug reports from Part A (title, steps, expected vs actual, severity)
- [ ] Your Part B answers: the API's reported balance, your SQL query, the
      correct balance you calculated, and your explanation of the discrepancy
- [ ] Your Part C findings on the `/admin/loans` auth behavior, with severity
- [ ] Your exported Postman collection (`.json` file — in Postman: click the
      three dots next to your collection → Export)
- [ ] Your short write-up for Part D

You can either fill in `Submission_Template.docx` directly and attach it, or
write your own document — whichever is easier for you. Attach the Postman
collection export as a separate file.

## What happens next

After you submit, we'll schedule a short call where you walk us through Part B
in particular — the reasoning matters more than getting the exact number right
on the first try.
